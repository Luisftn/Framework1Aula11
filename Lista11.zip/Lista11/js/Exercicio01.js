$(function(){
setInterval(function() {
    $('h1').fadeOut('slow');
    $('h1').fadeIn('slow');
},1000);



$('#ItensSeco').focus(function() {
    $('#ItensSeco').css("background-color", "black");
    $('#ItensSeco').css("color", "white");
})
$('#ItensSeco').blur(function() {
    $('#ItensSeco').css("background-color", "black");
    $('#ItensSeco').css("color", "white");
})

$('#ItensMolhado').focus(function() {
    $('#ItensMolhado').css("background-color", "black");
    $('#ItensMolhado').css("color", "white");
})
$('#ItensMolhado').blur(function() {
    $('#ItensMolhado').css("background-color", "black");    
    $('#ItensMolhado').css("color", "white");
})

$('#ItensFragil').focus(function() {
    $('#ItensFragil').css("background-color", "black");
    $('#ItensFragil').css("color", "white");
})
$('#ItensFragil').blur(function() {
    $('#ItensFragil').css("background-color", "black");
    $('#ItensFragil').css("color", "white");
})



$('#TotalSeco').focus(function() {
    $('#TotalSeco').css("background-color", "black");
    $('#TotalSeco').css("color", "white");
})
$('#TotalSeco').blur(function() {
    $('#TotalSeco').css("background-color", "black");
    $('#TotalSeco').css("color", "white");
})

$('#TotalMolhado').focus(function() {
    $('#TotalMolhado').css("background-color", "black");
    $('#TotalMolhado').css("color", "white");
})
$('#TotalMolhado').blur(function() {
    $('#TotalMolhado').css("background-color", "black");
    $('#TotalMolhado').css("color", "white");
})

$('#TotalFragil').focus(function() {
    $('#TotalFragil').css("background-color", "black");
    $('#TotalFragil').css("color", "white");
})
$('#TotalFragil').blur(function() {
    $('#TotalFragil').css("background-color", "black");
    $('#TotalFragil').css("color", "white");
})



});